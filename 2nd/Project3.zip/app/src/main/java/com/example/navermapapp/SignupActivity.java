package com.example.navermapapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class SignupActivity extends AppCompatActivity {
    Button btn_introback, btn_register;

    //비밀번호
    private EditText inputPass, inputPass_check;
    private ImageView setImage;

    private EditText inputID, inputName, inputPhone, inputNum;
    private CheckBox checkBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        NetworkUtil.setNetworkPolicy();

        btn_introback = findViewById(R.id.btn_introback);
        btn_introback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getApplicationContext(), IntroActivity.class);
                startActivity(it);
            }
        });

        inputID = findViewById(R.id.ed_register_id);
        inputID.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        checkBox = findViewById(R.id.checkBox);
        inputName = findViewById(R.id.ed_register_name);
        inputNum = findViewById(R.id.ed_register_num);
        inputPhone = findViewById(R.id.ed_register_phone);
        btn_register = findViewById(R.id.btn_register);
        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ID = inputID.getText().toString().trim();
                String Name = inputName.getText().toString().trim();
                String PWD = inputPass.getText().toString().trim();
                String PWD_check = inputPass_check.getText().toString().trim();
                String Phone = inputPhone.getText().toString().trim();
                String Num = inputNum.getText().toString().trim();
                boolean Check = checkBox.isChecked();

                if(ID.isEmpty() || Name.isEmpty() || PWD.isEmpty() || PWD_check.isEmpty()
                        && Phone.isEmpty() || Num.isEmpty()) {
                    Toast.makeText(getApplicationContext(),"필수사항은 모두 입력하세요!",Toast.LENGTH_SHORT).show();
                    return;
                }else{

                    try {
                        PHPRequest request = new PHPRequest("ci2020six.dongyangmirae.kr/bfglasses/member_join.php");
                        String result = request.PhPtest(ID, PWD, Name, Phone, Num, Check);
                        if(result.equals("1")){
                            Toast.makeText(getApplicationContext(),"들어감",Toast.LENGTH_SHORT).show();
                        }else{
                            Toast.makeText(getApplicationContext(),"안들어감",Toast.LENGTH_SHORT).show();
                        }
                    }catch (Exception e){
                        e.printStackTrace();
                    }

                    Intent it = new Intent(getApplicationContext(), LoginActivity.class);
                    startActivity(it);
                    //finish();
                }
            }
        });

        setImage = findViewById(R.id.setImage);
        inputPass = findViewById(R.id.ed_register_pass);
        inputPass_check = findViewById(R.id.ed_register_passcheck);
        inputPass_check.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(inputPass.getText().toString().equals(inputPass_check.getText().toString())){
                    setImage.setImageResource(R.drawable.ic_check);
                }else{
                    setImage.setImageResource(R.drawable.ic_currect);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }
}
