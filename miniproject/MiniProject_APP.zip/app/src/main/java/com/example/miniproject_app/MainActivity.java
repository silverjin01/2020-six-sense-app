package com.example.miniproject_app;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;


import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;

import java.io.InputStream;
import java.io.InputStreamReader;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    private static String TAG = "phptest_MainActivity";

    private static final String TAG_JSON="ci2020six";
    private static final String TAG_BUTTON = "button";
    private static final String TAG_TEMP = "temp";

    private TextView mTextViewResult;
    ArrayList<HashMap<String, String>> mArrayList;
    ListView mlistView;
    String mJsonString;

    TextView textView_list_button, textView_list_temp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextViewResult = (TextView) findViewById(R.id.textView_main_result);
        mlistView = (ListView) findViewById(R.id.listView_main_list);

        textView_list_button = findViewById(R.id.textView_list_id);
        textView_list_temp = findViewById(R.id.textView_list_name);

        mArrayList = new ArrayList<>();

        GetData task = new GetData();
        task.execute("http://ci2020six.dongyangmirae.kr/Arduino/getjson.php");
    }


    private class GetData extends AsyncTask<String, Void, String>{
        ProgressDialog progressDialog;
        String errorString = null;

        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            progressDialog = ProgressDialog.show(MainActivity.this,
                    "Please Wait", null, true, true);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            progressDialog.dismiss();
            mTextViewResult.setText(result);
            Log.d(TAG, "response  - " + result);
            if (result == null){

                mTextViewResult.setText(errorString);
            } else {

                mJsonString = result;
                //showResult();
                /*
                JsonObject json = (JsonObject) JsonParser.parseString(result);
                JsonArray stores = (JsonArray) json.get("stores");
                StringBuffer sBuf1 = new StringBuffer();
                StringBuffer sBuf2 = new StringBuffer();
                for(int i = 0; i <stores.size(); i++){
                    JsonObject store = (JsonObject)stores.get(i);
                    JsonElement button = store.get("button");
                    JsonElement temp = store.get("temp");
                    sBuf1.append(button.getAsString());//스트링타입으로 가져옴
                    sBuf1.append("버튼 : ").append(button.getAsString());
                    sBuf2.append(temp.getAsString());
                    sBuf2.append("온습도 : ").append(temp.getAsString());
                }
                textView_list_button.setText(sBuf1.toString());
                textView_list_temp.setText(sBuf2.toString());*/

                try {
                    JsonObject jsonObject = (JsonObject) JsonParser.parseString(result);
                    JsonArray jsonArray = (JsonArray) jsonObject.get(TAG_JSON);
                    StringBuffer stringBuffer = new StringBuffer();

                    for(int i=0; i<jsonArray.size(); i++){
                        JsonObject item = (JsonObject) jsonArray.get(i);
                        JsonElement btn = item.get("button");
                        JsonElement temp = item.get("temp");

                        HashMap<String,String> hashMap = new HashMap<>();

                        hashMap.put("button", btn.toString());
                        hashMap.put("temp", temp.toString());

                        mArrayList.add(hashMap);
                    }

                    ListAdapter adapter = new SimpleAdapter(
                            MainActivity.this, mArrayList, R.layout.list_item,
                            new String[]{TAG_BUTTON,TAG_TEMP, TAG_BUTTON},
                            new int[]{R.id.textView_list_id, R.id.textView_list_name}
                    );

                    mlistView.setAdapter(adapter);

                } catch (Exception e) {

                    Log.d(TAG, "showResult : ", e);
                }
            }
        }


        @Override
        protected String doInBackground(String... params) {
            String serverURL = params[0];

            try {
                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.connect();

                int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                } else {
                    inputStream = httpURLConnection.getErrorStream();
                }

                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }

                bufferedReader.close();

                return sb.toString().trim();

            } catch (Exception e) {
                Log.d(TAG, "InsertData: Error ", e);
                errorString = e.toString();

                return null;
            }
        }
    }
/*
    private void showResult(){
        try {
            JSONObject jsonObject = new JSONObject(mJsonString);
            JSONArray jsonArray = jsonObject.getJSONArray(TAG_JSON);

            for(int i=0;i<jsonArray.length();i++){

                JSONObject item = jsonArray.getJSONObject(i);

                String id = item.getString(TAG_BUTTON);
                String name = item.getString(TAG_TEMP);

                HashMap<String,String> hashMap = new HashMap<>();

                hashMap.put(TAG_BUTTON, id);
                hashMap.put(TAG_TEMP, name);

                mArrayList.add(hashMap);
            }

            ListAdapter adapter = new SimpleAdapter(
                    MainActivity.this, mArrayList, R.layout.list_item,
                    new String[]{TAG_BUTTON,TAG_TEMP, TAG_BUTTON},
                    new int[]{R.id.textView_list_id, R.id.textView_list_name}
            );

            mlistView.setAdapter(adapter);

        } catch (JSONException e) {

            Log.d(TAG, "showResult : ", e);
        }

    }

 */

}