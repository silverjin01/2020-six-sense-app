package com.example.navermapapp;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

public class UserValidate extends StringRequest {
    //server url setting(php file 연동)
    final static private String URL = "http://ci2020six.dongyangmirae.kr/bfglasses/SeverSrc/member_ok.php";
    private Map<String, String> map;

    public UserValidate(String userID, Response.Listener<String> listener){
        super(Method.POST, URL, listener, null);

        map = new HashMap<>();
        map.put("ID",userID);
    }

    protected Map<String, String> getParse() throws AuthFailureError{
        return map;
    }

}
