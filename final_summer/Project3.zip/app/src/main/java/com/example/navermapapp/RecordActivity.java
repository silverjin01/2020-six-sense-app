package com.example.navermapapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class RecordActivity extends AppCompatActivity {
    private Button moniter_btn, record_btn, mypage_btn;

    private ImageButton btnB;
    private TextView textView;
    private Intent intent;
    private SpeechRecognizer recognizer;
    private Button show_list_btn;

    public void onClickDirect(View v) {
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ko-KR");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "말해주세요.");

        try {
            startActivityForResult(i, 101); //응답을 받아야하기 때문에 startActivityForResult를 사용
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"STT 기능을 제공하지 않았습니다.",Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 101 && resultCode == RESULT_OK){
            ArrayList<String> sttResult = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            String sttResult1 = sttResult.get(0);

            textView.setText(sttResult1);
            //Toast.makeText(getApplicationContext(),sttResult1,Toast.LENGTH_LONG).show();
            insertDB(sttResult1);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        textView = findViewById(R.id.textView);
        btnB = findViewById(R.id.imageButton2);

        //액티비티 넘기기
        show_list_btn = findViewById(R.id.show_list_btn);

        show_list_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getApplicationContext(), RecordListActivity.class);
                startActivity(it);
            }
        });

        //사용자에게 음성을 요구하고 음성 인식기를 통해 전송하는 활동을 시작합니다.
        intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        //음성인식을 위한 음성 인식기의 의도에 사용되는 여분의 키입니다.
        intent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
        //음성을 번역할 언어를 설정합니다.
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"ko-KR");
        recognizer = SpeechRecognizer.createSpeechRecognizer(this);
        recognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle bundle) {
                //사용자가 말하기 시작할 준비가 되면 호출됨
                textView.setText("음성인식 대기중...");
                Toast.makeText(getApplicationContext(),"음성인식을 시작합니다.",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onBeginningOfSpeech() {
                //사용자가 말하기 시작했을 때 호출됨
            }

            @Override
            public void onRmsChanged(float v) {
                //입력받는 소리의 크기를 알려줌
            }

            @Override
            public void onBufferReceived(byte[] bytes) {
                //사용자가 말을 시작하고 인식이 된 단어를 buffer에 담습니다.
            }

            @Override
            public void onEndOfSpeech() {
                //사용자가 말하기를 중지하면 호출됨
            }

            @Override
            public void onError(int i) {
                //네트워크 또는 인식 오류가 발생했을 때 호출
                if(i == SpeechRecognizer.ERROR_NETWORK_TIMEOUT)
                    textView.setText("말이 없어서 종료 되었어요.");
                Toast.makeText(getApplicationContext(),"error : "+ i, Toast.LENGTH_LONG).show();

                String message;
                switch (i) {
                    case SpeechRecognizer.ERROR_AUDIO:
                        message = "오디오 에러";
                        break;
                    case SpeechRecognizer.ERROR_CLIENT:
                        message = "클라이언트 에러";
                        break;
                    case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
                        message = "퍼미션 없음";
                        break;
                    case SpeechRecognizer.ERROR_NETWORK:
                        message = "네트워크 에러";
                        break;
                    case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
                        message = "네트웍 타임아웃";
                        break;
                    case SpeechRecognizer.ERROR_NO_MATCH:
                        message = "찾을 수 없음";
                        break;
                    case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                        message = "RECOGNIZER가 바쁨";
                        break;
                    case SpeechRecognizer.ERROR_SERVER:
                        message = "서버가 이상함";
                        break;
                    case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                        message = "말하는 시간초과";
                        break;
                    default:
                        message = "알 수 없는 오류임";
                        break;
                }
                Toast.makeText(getApplicationContext(), "에러가 발생하였습니다. : " + message,Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onResults(Bundle bundle) {
                //음성을 마치고 결과를 받음
                ArrayList<String> result = bundle.getStringArrayList(recognizer.RESULTS_RECOGNITION);
                //textView.setText(result.get(0));

                for(int i = 0; i < result.size(); i++){
                    textView.setText(result.get(i));
                }
                String STT_result = textView.getText().toString();
                insertDB(STT_result);
            }

            @Override
            public void onPartialResults(Bundle bundle) {
                //부분 인식 결과를 사용할 수 있을 때 호출
            }

            @Override
            public void onEvent(int i, Bundle bundle) {
                //향후 이벤트를 추가하기 위해 예약됨됨
            }
       });

        /*
        btnB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textView.setText("말하는 중...");
                recognizer.startListening(intent);
            }
        });
        */
    }

    public void onDestroy(){
        if(recognizer != null) {
            recognizer.destroy();
        }
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if(id == R.id.action_list) {
            Intent it = new Intent(getApplicationContext(), ProtectorListActivity.class);
            startActivity(it);
        } else if(id == R.id.action_modify) {
            Toast.makeText(getApplicationContext(),"회원정보수정 페이지로 이동합니다.",Toast.LENGTH_SHORT).show();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void insertDB(String STT){
        class InsertSTT extends AsyncTask<String,Void,String>{
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(RecordActivity.this, "Please Wait", null, true, true);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(String... params) {
                try {
                    String stt = (String) params[0];

                    String link = "http://ci2020six.dongyangmirae.kr/bfglasses/SeverSrc/insert_stt.php";
                    String data = URLEncoder.encode("SC_OutText","UTF-8")+"="+URLEncoder.encode(stt, "UTF-8");

                    URL url = new URL(link);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    conn.setRequestMethod("POST");

                    conn.setDoInput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                    wr.write(data);
                    wr.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    //Read Server Response
                    while ((line = reader.readLine())!=null){
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                }catch (Exception e){
                    return new String("Exception : "+e.getMessage());
                }
            }
        }
        InsertSTT task = new InsertSTT();
        task.execute(STT);
    }
}
