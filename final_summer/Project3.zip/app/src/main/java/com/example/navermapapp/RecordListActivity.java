package com.example.navermapapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class RecordListActivity extends AppCompatActivity {
    Button show_list_btn;
    ImageButton imageButton;
    FrameLayout editFrame;
    LinearLayout list_linear;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_list);

        imageButton = findViewById(R.id.imageButton);
        editFrame = findViewById(R.id.editFrame);
        list_linear = findViewById(R.id.list);
        show_list_btn = findViewById(R.id.show_list_btn);

        list_linear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getApplicationContext(), RecordActivity.class);
                startActivity(it);
            }
        });

    }

}
