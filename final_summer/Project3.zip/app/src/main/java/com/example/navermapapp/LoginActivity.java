package com.example.navermapapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.http.HttpResponseCache;
import android.nfc.Tag;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class LoginActivity extends AppCompatActivity {
    //로그인 Frame
    Button btn_introback, btn_login, btn_findID, btnfindID_ok, btn_findPWD, btn_back_login, btn_pass_check, btn_change;
    EditText inputID, inputPWD, inputName, inputPhone;
    FrameLayout Login_Frame, Find_ID_Frame, InfromID_Frame, Find_PW_Frame, Change_PW_Frame;
    TextView textView;

    ArrayList<HashMap<String, String>> mArrayList;
    String mJsonString;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        //프레임레이아웃
        Login_Frame = findViewById(R.id.Login_Frame);
        Find_ID_Frame = findViewById(R.id.Find_ID_Frame);
        InfromID_Frame = findViewById(R.id.InfromID_Frame);
        Find_PW_Frame = findViewById(R.id.Find_PW_Frame);
        Change_PW_Frame = findViewById(R.id.Change_PW_Frame);

        inputID = findViewById(R.id.input_login_id);
        inputPWD = findViewById(R.id.input_login_pwd);

        inputName = findViewById(R.id.input_name);
        inputPhone = findViewById(R.id.input_phone);

        mArrayList = new ArrayList<>();

        btn_introback = findViewById(R.id.btn_introback);
        btn_introback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getApplicationContext(), IntroActivity.class);
                startActivity(it);
            }
        });

        btn_login = findViewById(R.id.btn_login);
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String ID = inputID.getText().toString();
                String PW = inputPWD.getText().toString();

                if (ID.isEmpty() || PW.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "아이디와 비밀번호를 입력해주세요.", Toast.LENGTH_SHORT).show();
                    return;
                } else {
                    Intent it = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(it);
                    //DownloadTask task = new DownloadTask();
                    //task.execute("http://ci2020six.dongyangmirae.kr/bfglasses/SeverSrc/getjson.php");
                }
            }
        });
        /*************************************************************************/
        btn_findID = findViewById(R.id.btn_findID);
        btn_findID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login_Frame.setVisibility(View.GONE);
                Find_ID_Frame.setVisibility(View.VISIBLE);
                InfromID_Frame.setVisibility(View.GONE);
                Find_PW_Frame.setVisibility(View.GONE);
                Change_PW_Frame.setVisibility(View.GONE);
            }
        });

        btn_findPWD = findViewById(R.id.btn_findPWD);
        btn_findPWD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login_Frame.setVisibility(View.GONE);
                Find_ID_Frame.setVisibility(View.GONE);
                InfromID_Frame.setVisibility(View.GONE);
                Find_PW_Frame.setVisibility(View.VISIBLE);
                Change_PW_Frame.setVisibility(View.GONE);
            }
        });

        btnfindID_ok = findViewById(R.id.btnfindID_ok);
        btnfindID_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login_Frame.setVisibility(View.GONE);
                Find_ID_Frame.setVisibility(View.GONE);
                InfromID_Frame.setVisibility(View.VISIBLE);
                Find_PW_Frame.setVisibility(View.GONE);
                Change_PW_Frame.setVisibility(View.GONE);
            }
        });

        btn_back_login = findViewById(R.id.btn_back_login);
        btn_back_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login_Frame.setVisibility(View.VISIBLE);
                Find_ID_Frame.setVisibility(View.GONE);
                InfromID_Frame.setVisibility(View.GONE);
                Find_PW_Frame.setVisibility(View.GONE);
                Change_PW_Frame.setVisibility(View.GONE);
            }
        });

        btn_pass_check = findViewById(R.id.btn_pass_check);
        btn_pass_check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login_Frame.setVisibility(View.GONE);
                Find_ID_Frame.setVisibility(View.GONE);
                InfromID_Frame.setVisibility(View.GONE);
                Find_PW_Frame.setVisibility(View.GONE);
                Change_PW_Frame.setVisibility(View.VISIBLE);
            }
        });

        btn_change = findViewById(R.id.btn_change);
        btn_change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login_Frame.setVisibility(View.VISIBLE);
                Find_ID_Frame.setVisibility(View.GONE);
                InfromID_Frame.setVisibility(View.GONE);
                Find_PW_Frame.setVisibility(View.GONE);
                Change_PW_Frame.setVisibility(View.GONE);
            }
        });

        inputID = findViewById(R.id.input_login_id);
        inputPWD = findViewById(R.id.input_login_pwd);
    }

    class DownloadTask extends AsyncTask<String, Void, String> {

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute(s);
            if(s == null)
                return;
//            textView.setText(s);
            JsonObject json = (JsonObject) JsonParser.parseString(s);
            JsonArray stores = (JsonArray)json.get("Members");
            StringBuffer sBuf = new StringBuffer();
            for(int i = 0; i < stores.size(); i++){
                JsonObject store = (JsonObject)stores.get(i);
                JsonElement lat = store.get("ID");
                JsonElement lng = store.get("PW");
                JsonElement name = store.get("Name");
                sBuf.append("***********************************\n");
                sBuf.append(name.getAsString()); //스트링 타입으로 가져옴
                sBuf.append("멤버 : ").append(lat.getAsDouble()).append(", ").append(lng.getAsDouble()).append("\n");
                sBuf.append("***********************************\n");
            }
            textView.setText((sBuf.toString()));
        }

        @Override
        protected String doInBackground(String... strings) {
            String sUrl = strings[0];

            HttpURLConnection connection = null;
            try {
                URL url = new URL(sUrl);
                connection = (HttpURLConnection) url.openConnection();
                BufferedInputStream buf = new BufferedInputStream(connection.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(buf, "utf-8"));

                StringBuffer sBuf = new StringBuffer();
                String line = null;
                while ((line = bufferedReader.readLine()) != null) {
                    sBuf.append(line + "\n");
                    //sBuf.append(line).append("\n");
                }
                //스트림 해제
                bufferedReader.close();
                buf.close();
                connection.disconnect();
                return sBuf.toString();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

/*
    //진행 다이얼로그는 시간이 걸리는 작업을 하기 때문에 Thread 나 AsyncTask 클래스에 포함되어서 사용됩니다.
    //AsynckTask는 Thread를 사용할 일이 있을 때 좀 더 편리하게 이용할 수 있도록 안드로이드에서 지원하고 있는 클래스
    public class GetData extends AsyncTask<String, Void, String>{
        ProgressDialog progressDialog; //프로그레스 다이얼로그 = 앱에서 시간이 걸리는 작업을 수행할 때 이 클래스를 이용(실시간 진행 상태를 알려줌)

        @Override
        protected void onPreExecute() { //작업시작, ProgressDialog 객체를 생성하고 시작합니다.
            super.onPreExecute();

            progressDialog = ProgressDialog.show(LoginActivity.this,
                    "Please Wait", null, true, true);
        }

        @Override
        protected void onPostExecute(String s) { //종료, ProgressDialog 종료 기능을 구현합니다.
            super.onPostExecute(s);

            if (s == null)
                return;
            JsonObject json = (JsonObject) JsonParser.parseString(s);
            JsonArray members = (JsonArray) json.get("Members");

            StringBuffer sBuf1 = new StringBuffer();
            StringBuffer sBuf2 = new StringBuffer();
            StringBuffer sBuf3 = new StringBuffer();

            for (int i = 0; i < members.size(); i++){
                JsonObject member = (JsonObject) members.get(i);
                JsonElement mNum = member.get("M_Number");
                JsonElement id = member.get("ID");
                JsonElement pw = member.get("PW");
                JsonElement name = member.get("Name");

                sBuf1.append(id.getAsString());
                sBuf2.append(pw.getAsString());
                sBuf3.append(mNum.getAsInt());

            }

            textView.setText(sBuf1.toString());

            /*
            try {
                if (((inputID.equals(sBuf1.toString())) && (inputPWD.equals(sBuf2.toString())))){
                    Toast.makeText(getApplicationContext(),"login",Toast.LENGTH_LONG).show();
                    Intent it = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(it);
                }else {
                    Toast.makeText(getApplicationContext(), "다시 입력 바람", Toast.LENGTH_LONG).show();
                    return;
                }
            }catch (Exception e){
                Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                e.printStackTrace();
            }

             */

            /*
            progressDialog.dismiss();
            Log.d(TAG, "response  - " + s);
            if (s == null){
                Toast.makeText(getApplicationContext(), "오류오류", Toast.LENGTH_SHORT).show();
                return;
            } else {
                mJsonString = s;
                try {
                    JsonObject jsonObject = (JsonObject) JsonParser.parseString(s);
                    JsonArray jsonArray = (JsonArray) jsonObject.get(TAG_JSON);
                    //StringBuffer stringBuffer = new StringBuffer();

                    for (int i = 0; i < jsonArray.size(); i++) {
                        JsonObject item = (JsonObject) jsonArray.get(i);
                        JsonElement id = item.get("ID");
                        JsonElement pw = item.get("PW");
                        JsonElement m_num = item.get("M_Number");

                        HashMap<String, String> hashMap = new HashMap<>();

                        hashMap.put("M_Number", m_num.toString());
                        hashMap.put("ID", id.toString());
                        hashMap.put("PW", pw.toString());

                        mArrayList.add(hashMap);
                    }



                    /*
                    Adapter adapter1 = new SimpleAdapter(LoginActivity.this, mArrayList, R.layout.activity_login,
                            new String[]{TAG_ID}, new int[R.id.input_login_id]);
                    Adapter adapter2 = new SimpleAdapter(LoginActivity.this, mArrayList, R.layout.activity_login,
                            new String[]{TAG_PWD}, new int[]{R.id.input_login_pwd});

                    if ((inputID.equals(adapter1.toString()))&&(inputPWD.equals(adapter2.toString()))){
                        Toast.makeText(getApplicationContext(),"동일",Toast.LENGTH_SHORT).show();
                        Intent it = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(it);
                    }else{
                        Toast.makeText(getApplicationContext(),"다시 입력",Toast.LENGTH_SHORT).show();
                        return;
                    }


                } catch (Exception e) {
                    Log.d(TAG, "showResult : ", e);
                }
            }


        }

        @Override
        protected String doInBackground(String... params) { //진행중, ProgressDialog 의 진행정도를 표현해 줍니다.
            String serverURL = params[0];

            try {
                URL url = new URL(serverURL);
                HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.connect();

                BufferedInputStream buf = new BufferedInputStream(httpURLConnection.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(buf, "utf-8"));

                StringBuffer stringBuffer = new StringBuffer();
                String line = null;
                while ((line = bufferedReader.readLine())!=null){
                    stringBuffer.append(line+"\n");
                }
                bufferedReader.close();
                buf.close();
                httpURLConnection.disconnect();
                return stringBuffer.toString();


                /*int responseStatusCode = httpURLConnection.getResponseCode();
                Log.d(TAG, "response code - " + responseStatusCode);

                InputStream inputStream;
                if(responseStatusCode == HttpURLConnection.HTTP_OK) {
                    inputStream = httpURLConnection.getInputStream();
                } else {
                    inputStream = httpURLConnection.getErrorStream();
                }

                InputStreamReader inputStreamReader = new InputStreamReader(inputStream, "UTF-8");
                BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

                StringBuilder sb = new StringBuilder();
                String line;

                while((line = bufferedReader.readLine()) != null){
                    sb.append(line);
                }

                bufferedReader.close();
                return sb.toString().trim();


            } catch (Exception e) {
                Toast.makeText(getApplicationContext(),e.getMessage(),Toast.LENGTH_LONG).show();
                return null;
            }
        }
    }
    */
}