package com.example.navermapapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;

public class LoginActivity extends AppCompatActivity {
    //로그인 Frame
    Button btn_introback, btn_login, btn_findID, btnfindID_ok, btn_findPWD, btn_back_login, btn_pass_check, btn_change;
    EditText inputID, inputPWD;
    FrameLayout Login_Frame, Find_ID_Frame, InfromID_Frame, Find_PW_Frame, Change_PW_Frame;

    //DB Json
    private static String TAG = "phptest MainActivity";
    private static final String TAG_JSON ="ci2020six";
    private static final String TAG_ㅑID= "ID";
    private static final String TAG_PWD = "PWD";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //프레임레이아웃
        Login_Frame = findViewById(R.id.Login_Frame);
        Find_ID_Frame = findViewById(R.id.Find_ID_Frame);
        InfromID_Frame = findViewById(R.id.InfromID_Frame);
        Find_PW_Frame = findViewById(R.id.Find_PW_Frame);
        Change_PW_Frame = findViewById(R.id.Change_PW_Frame);


        btn_introback = findViewById(R.id.btn_introback);
        btn_introback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getApplicationContext(), IntroActivity.class);
                startActivity(it);
            }
        });

        btn_login = findViewById(R.id.btn_login);
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(it);
            }
        });

        /*************************************************************************/

        btn_findID = findViewById(R.id.btn_findID);
        btn_findID.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login_Frame.setVisibility(View.GONE);
                Find_ID_Frame.setVisibility(View.VISIBLE);
                InfromID_Frame.setVisibility(View.GONE);
                Find_PW_Frame.setVisibility(View.GONE);
                Change_PW_Frame.setVisibility(View.GONE);
            }
        });

        btn_findPWD = findViewById(R.id.btn_findPWD);
        btn_findPWD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login_Frame.setVisibility(View.GONE);
                Find_ID_Frame.setVisibility(View.GONE);
                InfromID_Frame.setVisibility(View.GONE);
                Find_PW_Frame.setVisibility(View.VISIBLE);
                Change_PW_Frame.setVisibility(View.GONE);
            }
        });

        btnfindID_ok = findViewById(R.id.btnfindID_ok);
        btnfindID_ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login_Frame.setVisibility(View.GONE);
                Find_ID_Frame.setVisibility(View.GONE);
                InfromID_Frame.setVisibility(View.VISIBLE);
                Find_PW_Frame.setVisibility(View.GONE);
                Change_PW_Frame.setVisibility(View.GONE);
            }
        });

        btn_back_login = findViewById(R.id.btn_back_login);
        btn_back_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login_Frame.setVisibility(View.VISIBLE);
                Find_ID_Frame.setVisibility(View.GONE);
                InfromID_Frame.setVisibility(View.GONE);
                Find_PW_Frame.setVisibility(View.GONE);
                Change_PW_Frame.setVisibility(View.GONE);
            }
        });

        btn_pass_check = findViewById(R.id.btn_pass_check);
        btn_pass_check.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login_Frame.setVisibility(View.GONE);
                Find_ID_Frame.setVisibility(View.GONE);
                InfromID_Frame.setVisibility(View.GONE);
                Find_PW_Frame.setVisibility(View.GONE);
                Change_PW_Frame.setVisibility(View.VISIBLE);
            }
        });

        btn_change = findViewById(R.id.btn_change);
        btn_change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Login_Frame.setVisibility(View.VISIBLE);
                Find_ID_Frame.setVisibility(View.GONE);
                InfromID_Frame.setVisibility(View.GONE);
                Find_PW_Frame.setVisibility(View.GONE);
                Change_PW_Frame.setVisibility(View.GONE);
            }
        });

        inputID = findViewById(R.id.input_login_id);
        inputPWD = findViewById(R.id.input_login_pwd);
    }

}
