package com.example.navermapapp;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Button moniter_btn, record_btn, mypage_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar); //툴바 설정(생성도 같이함)
        setSupportActionBar(toolbar); //액션바와 같게 만들어줌

        moniter_btn = findViewById(R.id.moniter_btn);
        record_btn = findViewById(R.id.record_btn);
        mypage_btn = findViewById(R.id.mypage_btn);

        moniter_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getApplicationContext(), MoniterActivity.class);
                startActivity(it);
            }
        });

        record_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getApplicationContext(), RecordActivity.class);
                startActivity(it);
            }
        });

        mypage_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getApplicationContext(),MypageActivity.class);
                startActivity(it);
            }
        });

    }

    //**Activity 시작할 때 앱 바에 항목을 표시하기 위해 시스템이 호출**//
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    //**사용자가 메뉴 항 목을 클릭하면 시스템에 의해 이 메소드가 호출됨 **//
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_list) {
            Intent it = new Intent(getApplicationContext(), ProtectorListActivity.class);
            startActivity(it);
        } else if (id == R.id.action_modify) {
            Intent it = new Intent(getApplicationContext(), ProtectorListActivity.class);
            startActivity(it);
        }

        return super.onOptionsItemSelected(item);
    }
}
