package com.example.navermapapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.Button;
import android.widget.ImageView;

public class IntroActivity extends AppCompatActivity  {
    image_adapter adapter;
    ViewPager viewPager;

    Button login_intro_btn, signup_intro_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);

        viewPager = (ViewPager) findViewById(R.id.pager);
        adapter = new image_adapter(this);
        viewPager.setAdapter(adapter);

        login_intro_btn = findViewById(R.id.login_intro_btn);
        signup_intro_btn = findViewById(R.id.signup_intro_btn);

        login_intro_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(it);
            }
        });

        signup_intro_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getApplicationContext(), SignupActivity.class);
                startActivity(it);
            }
        });
    }
}
