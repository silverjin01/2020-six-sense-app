package com.example.navermapapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class SignupActivity extends AppCompatActivity {
    Button btn_introback, btn_register;

    //비밀번호
    private EditText inputPass, inputPass_check;
    private ImageView setImage;

    private EditText inputID, inputName, inputPhone, inputNum;
    private CheckBox checkBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        //상단바
        btn_introback = findViewById(R.id.btn_introback);
        btn_introback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it = new Intent(getApplicationContext(), IntroActivity.class);
                startActivity(it);
            }
        });

        inputID = findViewById(R.id.ed_register_id); //1. 아이디
        inputID.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        checkBox = findViewById(R.id.checkBox); //5. 체크박수 보호자 여부
        inputName = findViewById(R.id.ed_register_name); //3. 이름
        inputNum = findViewById(R.id.ed_register_num);   //6. 기기고유번호
        inputPhone = findViewById(R.id.ed_register_phone); //4. 핸드폰
        btn_register = findViewById(R.id.btn_register);

        setImage = findViewById(R.id.setImage);
        inputPass = findViewById(R.id.ed_register_pass); //2. 비밀번호
        inputPass_check = findViewById(R.id.ed_register_passcheck); //비밀번호 확인
        inputPass_check.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if(inputPass.getText().toString().equals(inputPass_check.getText().toString())){
                    setImage.setImageResource(R.drawable.ic_check);
                }else{
                    setImage.setImageResource(R.drawable.ic_currect);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    public String protector(CheckBox checkBox){
        if (checkBox.isChecked()){
            return "1";
        }else {
            return "0";
        }
    }

    public void insert(View v){
         String ID = inputID.getText().toString().trim();
         String Name = inputName.getText().toString().trim();
         String PWD = inputPass.getText().toString().trim();
         String PWD_check = inputPass_check.getText().toString().trim();
         String Phone = inputPhone.getText().toString().trim();
         String Num = inputNum.getText().toString().trim();
         //String Check = ((String) checkBox.toString());
         String Check = protector(checkBox);


        if(ID.isEmpty() || Name.isEmpty() || PWD.isEmpty() || PWD_check.isEmpty()
                && Phone.isEmpty() || Num.isEmpty()) {
            Toast.makeText(getApplicationContext(),"필수사항은 모두 입력하세요!",Toast.LENGTH_SHORT).show();
            return;
        }else{
            Intent it = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(it);
        }

        insertDB(ID, PWD, Name, Phone, Check, Num);
    }
    private void insertDB(String ID, String PWD, final String Name, String Phone, String Check, String Num){
        class  InsertData extends AsyncTask<String, Void, String>{
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(SignupActivity.this, "Please Wait", null, true, true);
            }

            @Override
            protected String doInBackground(String... params) {
                try {
                    String id = (String) params[0];
                    String pwd = (String) params[1];
                    String name = (String) params[2];
                    String phone = (String) params[3];
                    String check = (String) params[4];
                    String Num = (String) params[5];

                    String link = "http://ci2020six.dongyangmirae.kr/bfglasses/member_join.php";
                    String data = URLEncoder.encode("ID","UTF-8") + "=" + URLEncoder.encode(id,"UTF-8");
                    data += "&" + URLEncoder.encode("PW", "UTF-8") + "=" + URLEncoder.encode(pwd, "UTF-8");
                    data += "&" + URLEncoder.encode("Name", "UTF-8") + "=" + URLEncoder.encode(name, "UTF-8");
                    data += "&" + URLEncoder.encode("Phone","UTF-8") + "=" + URLEncoder.encode(phone, "UTF-8");
                    data += "&" + URLEncoder.encode("Division","UTF-8") + "=" + URLEncoder.encode(check, "UTF-8");
                    data += "&" + URLEncoder.encode("SNumber","UTF-8") + "=" + URLEncoder.encode(Num, "UTF-8");

                    URL url = new URL(link);
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                    conn.setRequestMethod("POST");

                    conn.setDoInput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                    wr.write(data);
                    //wr.write(link);
                    wr.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    //Read Server Response
                    while ((line = reader.readLine())!=null){
                        sb.append(line);
                        break;
                    }
                    return sb.toString();

                }catch (Exception e){
                    return new String("Exception: "+e.getMessage());
                }
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(getApplicationContext(),s,Toast.LENGTH_LONG).show();
            }
        }
        InsertData task = new InsertData();
        task.execute(ID,PWD,Name,Phone, Check,Num);
    }
}
